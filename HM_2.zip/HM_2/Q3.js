function primeFactors(n){
    document.write('Prime factors:' + '</br>')
    while (n % 2 == 0)
    {
        document.write(2 + '</br>');
        n = Math.floor(n / 2);
    }
    for(let i = 3;
            i <= Math.floor(Math.sqrt(n));
            i = i + 2)
    {
        while (n % i == 0)
        {
            document.write(i + '</br>');
            n = Math.floor(n / i);
        }
    }
    if (n > 2)
        document.write(n + '</br>');
}
 
let n = window.prompt("Enter an integer:");

primeFactors(n);