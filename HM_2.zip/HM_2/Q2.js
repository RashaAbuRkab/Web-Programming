let rasha = true;
let word ;
let str;
function subString(str,n){
	for (let len = 1; len <= n; len++) {
		for (let i = 0; i <= n - len; i++) {
			let j = i + len - 1;
			for (let k = i; k <= j; k++) {
				document.write(str[k]);
			}
			document.write("<br>");
		}
	}
}

word = prompt("Enter a string or an empty string to terminate the program");
str= word;
if(str.length === 0){ 	
	 document.write("Done !");
	 rasha = false;
 }
 else{
	subString(str, str.length);
 }
