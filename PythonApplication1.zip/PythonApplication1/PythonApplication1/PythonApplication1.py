import pandas as pd
print("Q1")
Company_data= pd.DataFrame( {'Day': ['2/1/2022','2/2/2022','3/2/2022','4/2/2022'],'Buying': [2000,1500,3000,2100],
'Selling': [600,700,200,1000],'Income': ['Medium', 'Medium', 'Low','High']})
print('the max and min of the Buying' ,max(Company_data.Buying),',',min(Company_data.Buying))
print('the max and min of the Selling' ,max(Company_data.Selling),',',min(Company_data.Selling))
print()

#%%
import numpy as np
print("Q2")
weather_data =pd.DataFrame([('4/1/2022',32,40,'Sunny'),('4/2/2022',35,50,'not-available'),('4/3/2022',20,20,'Windy'),
('4/4/2022',15,28,'not-available'),('4/5/2022',3,30,'Snowy')],columns=["Day", "Temperature", "Humidity", "Event"])
weather_data.replace('not-available', np.nan)
print(weather_data)
print()

#%%
print("describe Data")
print(weather_data.describe())
print()

#%%
print("Q3")
arr = np.random.seed(1234)
# a1 = np.ones([10,10])
a1 =  np.random.randint(100,size=(10,10))
print(f'array with size 10 by 10 with name a1 and the data type is an integer with a maximum value of 100:\n\n{a1}')
a2 = np.random.normal(size=(10,10))
print(f'\narray from a normal distribution with the size of size 10 by 10:\n\n{a2}')
a3 = np.random.uniform(size=(10,10))
print(f'\narray from a uniform distribution with the size of size 10 by 10:\n\n{a3}')
a4 = np.random.choice([5,10,15],size=(10,10))
print(f'\narray with only choice over list [5,10,15] and with size 10 by 10:\n\n{a4}')
print()

#%%
print("Q4")
import numpy as np
arr1= np.array([[ 50, 20, 3, 4, 1], [ 10, 4, 9, 8, 30], [15, 6, 27, 15, 7]])
print('1) the second column: ' ,arr1[0,1],arr1[1,1],arr1[2,1])
print('2) the element that is in row 2 and column 3: ' ,arr1[1,2])
print('3) all elements in rows 1,and 2:\n' , arr1[:2])
print()

#%%
print("Q5")
arr2= np.array([[[10], [20], [30],[40]]])
print('the Output from Drop any axis with length = 1 :',np.squeeze(arr2)) 